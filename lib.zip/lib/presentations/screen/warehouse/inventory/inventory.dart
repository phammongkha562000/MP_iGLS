export 'inventory_view.dart';
export 'inventory_view_detail.dart';
