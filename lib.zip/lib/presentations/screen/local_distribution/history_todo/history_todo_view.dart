import 'dart:developer';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:igls_new/businesses_logics/bloc/local_distribution/history_todo/history_todo_bloc.dart';
import 'package:igls_new/data/models/local_distribution/history_todo/history_todo_response.dart';
import 'package:igls_new/data/shared/utils/formatdate.dart';
import 'package:igls_new/presentations/presentations.dart';
import 'package:igls_new/data/services/navigator/route_path.dart' as routes;
import 'package:igls_new/presentations/common/key_params.dart' as key_params;
import 'package:igls_new/presentations/common/constants.dart' as constants;

import '../../../../businesses_logics/bloc/general/general_bloc.dart';
import '../../../../data/services/injection/injection_igls.dart';
import '../../../../data/services/navigator/navigation_service.dart';
import '../../../widgets/app_bar_custom.dart';
import '../../../widgets/table_widget/table_widget.dart';

class HistoryTodoView extends StatefulWidget {
  const HistoryTodoView({super.key});

  @override
  State<HistoryTodoView> createState() => _HistoryTodoViewState();
}

class _HistoryTodoViewState extends State<HistoryTodoView> {
  final _navigationService = getIt<NavigationService>();
  late HistoryTodoBloc _bloc;
  late GeneralBloc generalBloc;
  @override
  void initState() {
    generalBloc = BlocProvider.of<GeneralBloc>(context);
    _bloc = BlocProvider.of<HistoryTodoBloc>(context);
    _bloc
        .add(HistoryTodoLoaded(date: DateTime.now(), generalBloc: generalBloc));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBarCustom(
        title: Text(
          "4090".tr(),
        ),
      ),
      body: BlocConsumer<HistoryTodoBloc, HistoryTodoState>(
        listener: (context, state) {
          if (state is HistoryTodoFailure) {
            if (state.errorCode == constants.errorNullEquipDriverId) {
              CustomDialog().error(context,
                  err: state.message,
                  btnOkOnPress: () => Navigator.of(context).pop());

              return;
            }
            CustomDialog().error(context, err: state.message);
          }
        },
        builder: (context, state) {
          if (state is HistoryTodoSuccess) {
            log("${state.listHistoryTodo!.length}");
            return PickDatePreviousNextWidget(
              isMonth: true,
              onTapPrevious: () {
                _bloc.add(HistoryTodoPreviousMonth(generalBloc: generalBloc));
              },
              onTapNext: () {
                _bloc.add(HistoryTodoNextMonth(generalBloc: generalBloc));
              },
              onTapPick: (selectDate) {
                _bloc.add(HistoryTodoLoaded(
                    date: selectDate, generalBloc: generalBloc));
              },
              stateDate: state.date,
              quantityText: "${state.listHistoryTodo!.length}",
              child: _buildTable(todoList: state.listHistoryTodo ?? []),
            );
          }
          return const ItemLoading();
        },
      ),
    );
  }

  List<Widget> _headerTable() {
    return const [
      HeaderTable2Widget(label: '1277', width: 50),
      HeaderTable2Widget(label: '2501', width: 80),
      HeaderTable2Widget(label: '3597', width: 120),
      HeaderTable2Widget(label: '2482', width: 300),
      HeaderTable2Widget(label: '1279', width: 110),
      HeaderTable2Widget(label: '4519', width: 300)
    ];
  }

  Widget _buildTable({required List<HistoryNormalTrip> todoList}) {
    return TableDataWidget(
        listTableRowHeader: _headerTable(),
        listTableRowContent: todoList.isEmpty
            ? [const CellTableNoDataWidget(width: 960)]
            : List.generate(
                todoList.length,
                (index) {
                  return ColoredBox(
                    color: colorRowTable(index: index),
                    child: InkWell(
                      onTap: todoList[index].tripNo!.startsWith('S')
                          ? () async {
                              _navigationService.pushNamed(
                                  routes.historyTodoSimpleRoute,
                                  args: {
                                    key_params.tripHistory: todoList[index],
                                  });
                            }
                          : () async {
                              _navigationService.pushNamed(
                                  routes.historyTodoNormalRoute,
                                  args: {
                                    key_params.tripHistory: todoList[index],
                                  });
                            },
                      child: Row(
                        children: [
                          CellTableWidget(
                              width: 50, content: (index + 1).toString()),
                          CellTableWidget(
                              width: 80,
                              content: FormatDateConstants.convertddMM(
                                  todoList[index].etp ?? '')),
                          CellTableWidget(
                              width: 120,
                              content: todoList[index].contactCode ?? ''),
                          CellTableWidget(
                              width: 300,
                              isAlignLeft: true,
                              content: todoList[index].shipToName ?? ''),
                          CellTableWidget(
                              width: 110,
                              content: todoList[index].tripStatus ?? ''),
                          CellTableWidget(
                              width: 300,
                              content: todoList[index].driverTripTypeDesc ?? '')
                        ],
                      ),
                    ),
                  );
                },
              ));
  }
}
