import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_widget/google_maps_widget.dart';
import 'package:igls_new/presentations/common/constants.dart' as constants;
import 'package:igls_new/presentations/common/assets.dart' as assets;
import 'package:igls_new/presentations/common/colors.dart' as colors;
import 'package:url_launcher/url_launcher.dart';
import 'package:maps_launcher/maps_launcher.dart';

import '../../../widgets/app_bar_custom.dart';

class MapView extends StatefulWidget {
  const MapView(
      {super.key,
      required this.picLat,
      required this.picLon,
      required this.shpLat,
      required this.shpLon});
  final double picLat;
  final double picLon;
  final double shpLat;
  final double shpLon;
  @override
  State<MapView> createState() => MapViewState();
}

class MapViewState extends State<MapView> {
  double lat = 0;
  double lon = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBarCustom(title: Text('5201'.tr())),
        body: GoogleMapsWidget(
          sourceMarkerIconInfo: MarkerIconInfo(
              assetPath: assets.locationStart,
              assetMarkerSize: const Size(150, 150),
              infoWindowTitle: '3573'.tr()),
          destinationMarkerIconInfo: MarkerIconInfo(
              assetPath: assets.locationEnd,
              assetMarkerSize: const Size(100, 100),
              infoWindowTitle: '141'.tr()),
          myLocationEnabled: true,
          apiKey: constants.apiKeyGGMap,
          sourceLatLng: LatLng(widget.picLat, widget.picLon),
          destinationLatLng: LatLng(widget.shpLat, widget.shpLon),
        ),
        floatingActionButton: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            _buildBtnDirection(
                lat: widget.picLat,
                lon: widget.picLon,
                text: '5202'.tr(),
                isPick: true),
            const SizedBox(
              width: 4,
            ),
            _buildBtnDirection(
                lat: widget.shpLat,
                lon: widget.shpLon,
                text: '5203'.tr(),
                isPick: false),
          ],
        ));
  }

  Widget _buildBtnDirection(
      {required double lat,
      required double lon,
      required String text,
      bool? isPick}) {
    return ElevatedButton(
        onPressed: () async {
          String url = 'google.navigation:q=$lat,$lon';
          Platform.isIOS
              ? MapsLauncher.launchCoordinates(lat, lon)
              : _launchURL(url);
        },
        style: ButtonStyle(
            minimumSize: MaterialStateProperty.all(const Size(100, 55)),
            shape: MaterialStateProperty.all(RoundedRectangleBorder(
                borderRadius: isPick ?? false
                    ? const BorderRadius.only(
                        topLeft: Radius.circular(32),
                        bottomLeft: Radius.circular(32))
                    : const BorderRadius.only(
                        topRight: Radius.circular(32),
                        bottomRight: Radius.circular(32)))),
            backgroundColor: MaterialStateProperty.all(colors.defaultColor)),
        child: Text(
          text,
          style: const TextStyle(
              color: colors.textWhite, fontWeight: FontWeight.bold),
        ));
  }

  void _launchURL(String url) async {
    if (await canLaunchUrl(Uri.parse(url))) {
      await launchUrl(Uri.parse(url));
    } else {
      throw 'Could not launch $url';
    }
  }
}
