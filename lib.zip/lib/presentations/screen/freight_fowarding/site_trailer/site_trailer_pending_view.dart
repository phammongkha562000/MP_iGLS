import 'package:flutter/material.dart';
import 'package:igls_new/data/services/navigator/navigator.dart';
import 'package:igls_new/presentations/common/colors.dart' as colors;
import 'package:igls_new/presentations/widgets/components/drop_down_button_form_field2_widget.dart';

import '../../../../businesses_logics/bloc/freight_fowarding/site_trailer_check/site_trailer_pending/site_trailer_pending_bloc.dart';
import '../../../../businesses_logics/bloc/general/general_bloc.dart';
import '../../../../data/shared/utils/file_utils.dart';
import '../../../widgets/admin_component/cell_table.dart';
import '../../../widgets/admin_component/header_table.dart';
import '../../../widgets/app_bar_custom.dart';
import '../../../widgets/table_widget/cell_table_no_data.dart';
import '../../../widgets/table_widget/table_data.dart';

class SiteTrailerPendingView extends StatefulWidget {
  const SiteTrailerPendingView({super.key});
  @override
  State<SiteTrailerPendingView> createState() => _SiteTrailerPendingViewState();
}

class _SiteTrailerPendingViewState extends State<SiteTrailerPendingView> {
  late GeneralBloc generalBloc;
  late SiteTrailerPendingBloc _bloc;
  final ValueNotifier<CySiteResponse> _cyNotifier =
      ValueNotifier<CySiteResponse>(
          CySiteResponse(cyCode: '', cyName: '5059'.tr()));

  CySiteResponse? cySelected;
  @override
  void initState() {
    generalBloc = BlocProvider.of<GeneralBloc>(context);
    _bloc = BlocProvider.of<SiteTrailerPendingBloc>(context);
    _bloc.add(SiteTrailerPendingLoad(generalBloc: generalBloc));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    List<CySiteResponse> listLocalCy = <CySiteResponse>[
      CySiteResponse(cyCode: '', cyName: '5059'.tr()),
    ];
    listLocalCy.addAll(generalBloc.listCY);
    return Scaffold(
        appBar: AppBarCustom(title: Text('5444'.tr())),
        body: BlocConsumer<SiteTrailerPendingBloc, SiteTrailerPendingState>(
          listener: (context, state) {
            if (state is SiteTrailerPendingFailure) {
              CustomDialog().error(context, err: state.message);
            }
          },
          builder: (context, state) {
            if (state is SiteTrailerPendingSuccess) {
              return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.symmetric(
                          horizontal: MediaQuery.sizeOf(context).height * 0.015,
                          vertical: MediaQuery.sizeOf(context).height * 0.03),
                      child: ValueListenableBuilder(
                        valueListenable: _cyNotifier,
                        builder: (context, value, child) =>
                            DropDownButtonFormField2CYSiteWidget(
                          onChanged: (value) {
                            value as CySiteResponse;
                            _cyNotifier.value = value;
                            cySelected = value;
                            BlocProvider.of<SiteTrailerPendingBloc>(context)
                                .add(SiteTrailerPendingFilterByCY(
                                    cyName: value.cyName ?? ''));
                          },
                          value: cySelected ?? listLocalCy[0],
                          hintText: '5083',
                          label: '5124',
                          list: listLocalCy,
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                        vertical: 12,
                        horizontal: MediaQuery.sizeOf(context).height * 0.015,
                      ),
                      child: Text(
                        '${state.lstTrailerPendingFilter.length} ${'5444'.tr()}',
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16),
                      ),
                    ),
                    TableDataWidget(
                        listTableRowHeader: _headerTable(),
                        listTableRowContent: (state.lstTrailerPendingFilter ==
                                    [] ||
                                state.lstTrailerPendingFilter.isEmpty)
                            ? [const CellTableNoDataWidget(width: 820)]
                            : List.generate(
                                state.lstTrailerPendingFilter.length, (i) {
                                final item = state.lstTrailerPendingFilter[i];
                                return ColoredBox(
                                  color: colorRowTable(index: i),
                                  child: Row(children: [
                                    CellTableWidget(
                                        content: (i + 1).toString(), width: 50),
                                    _buildTrailerNo(
                                        trailerNo: item.trailerNumber ?? ''),
                                    CellTableWidget(
                                        content: item.lastCheckDate != null &&
                                                item.lastCheckDate != ''
                                            ? FileUtils
                                                .convertDateForHistoryDetailItem(
                                                    item.lastCheckDate ?? '')
                                            : '',
                                        width: 150),
                                    CellTableWidget(
                                        content: item.lastCYName ?? '',
                                        width: 200),
                                    CellTableWidget(
                                        content: item.lastRemark ?? '',
                                        isAlignLeft: true,
                                        width: 300),
                                  ]),
                                );
                              })),
                  ]);
            }
            return const ItemLoading();
          },
        ));
  }

  Widget _buildTrailerNo({
    required String trailerNo,
  }) {
    return Container(
      width: 120,
      height: 50,
      decoration: const BoxDecoration(
          border: Border(
              right: BorderSide(
        color: Colors.black38,
      ))),
      child: Padding(
        padding: const EdgeInsets.all(8),
        child: TextButton(
            style: ButtonStyle(
                backgroundColor:
                    MaterialStateProperty.all(colors.defaultColor)),
            child: Text(
              trailerNo,
              style: const TextStyle(color: Colors.white),
            ),
            onPressed: () {
              Navigator.pop(context, trailerNo);
            }),
      ),
    );
  }

  List<Widget> _headerTable() {
    return [
      const HeaderTable2Widget(label: '1277', width: 50),
      const HeaderTable2Widget(label: '4012', width: 120),
      const HeaderTable2Widget(label: '5445', width: 150),
      const HeaderTable2Widget(label: '5446', width: 200),
      const HeaderTable2Widget(label: '1276', width: 300),
    ];
  }
}
