//title by menuID, parentsMenu
String getTitleMenuByMenuID({required String menuId}) {
  switch (menuId) {
    case 'MB0056':
      return '4779';
    case 'MB1001':
      return '2428';
    case 'MB0057':
      return '4021';
    case 'MB0011':
      return '93';
    case 'MB0031':
      return '4550';
    case 'MB0014':
      return '2400';
    case 'MB0071':
      return '1299';
    case 'MB0023':
      return '3998';
    case 'MB0032':
      return '5483';
    // return '4551';
    case 'MB0012':
      return '162';
    case 'MB0024':
      return '4090';
    case 'M00006':
      return '4804';
    case 'MB1004':
      return '4672';
    case 'MB0052':
      return '4474';
    case 'MB0072':
      return '4040';
    case 'MB0073':
      return '1298';
    case 'MB0013':
      return '226';
    case 'MB0033':
      return '4726';
    case 'MB0053':
      return '4676';
    case 'MB0034':
      return '21';
    case 'MB1005':
      return '4673';
    case 'MB0055':
      return '4769';
    case 'MB0015':
      return '1294';
    case 'MB0026':
      return '4213';
    case 'M1015':
      return '4891';
    case 'MB0027':
      return '4884';
    case 'MB0017':
      return '3725';
    case 'MB0029':
      return '4892';
    case 'M1000':
      return '1321';

    case 'MB001':
      return '3997';
    case 'MB003':
      return '103';

    case 'MB007':
      return '4830';

    case 'MB005':
      return '4791';
    case 'MB002':
      return '5043';
    case 'MB0018':
      return '4883';
    case 'MB0054':
      return '4719';
    default:
      return '';
  }
}
