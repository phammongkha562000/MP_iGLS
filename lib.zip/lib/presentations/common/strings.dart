const noPath = 'No path for';
const nameApp = 'iGLS MOBILE';

const String erPassNotMatch = "5167";

const String erRegisterFail = "Registration failed";
const String erGreaterThan0 = "5175";
const String erPasswordShort = "5174";

const unknown = "Unknown";

const messError = 'MessError';
const messErrorNoEquipment = '5145';

//enum trip type
const normalTripType = 'Normal trip';
const simpleTripType = 'Simple trip';

//enum trade type
const exportTradeType = 'Export';
const importTradeType = 'Import';
const allType = '';

String errIsNotAllowBiometric = "5173";
String errInitLogin = "5170";
String errFirstAccLoginWithBiometrics = "5171";
String errBiometrics = "5172";

const errMess401 = '5435';
const errMess400 = '5436';