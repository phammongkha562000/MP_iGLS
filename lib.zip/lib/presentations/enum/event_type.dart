class EventTypeValue {
  static const String pickkupEvent = "400";
  static const String completedTripEvent = "800";
  static const String startDeliveryEvent = "500";
  static const String updatePositionEvent = "700";
  static const String updateOrderStatus = "600";
}
