class DeliveryResult {
  static const String fullSuccessResult = "S";
  static const String apartSuccessResult = "P";
  static const String failResult = "F";
}
