class StatusTaskHistory {
  static const String all = "";
  static const String newStatus = "NEW";
  static const String completeStatus = "COMPLETE";
}
