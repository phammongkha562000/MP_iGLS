import 'package:flutter/material.dart';

class RowFlex5and5 extends StatelessWidget {
  const RowFlex5and5({
    super.key,
    required this.left,
    required this.right,
  }) ;

  final Widget left;
  final Widget right;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          flex: 5,
          child: left,
        ),
        Expanded(
          flex: 5,
          child: right,
        ),
      ],
    );
  }
}
