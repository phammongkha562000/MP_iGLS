export 'global_app.dart';
