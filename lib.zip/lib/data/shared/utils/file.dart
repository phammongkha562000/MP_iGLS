const fileUserInfo = 'file_user_info';
const fileContactLocal = 'file_contact_local';
const fileCySite = 'file_cy_site';
const filePageMenuPermissions = 'file_page_menu';
const List<String> filesLogOut = [
  fileContactLocal,
  fileUserInfo,
  filePageMenuPermissions,
  fileCySite
];
