class GlobalContactFormat {
  String? format;
  String? get getFormat => format;

  set setFormat(String? value) => format = value;
}

GlobalContactFormat globalContactFormat = GlobalContactFormat();
