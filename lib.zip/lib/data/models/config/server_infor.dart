class ServerInfo {
  String? serverCode;
  String? notificationServerName;
  String? serverAddress;
  String? serverWcf;
  String? serverHub;
  String? systemId;
  String? serverSalary;
  ServerInfo({
    this.serverCode,
    this.notificationServerName,
    this.serverAddress,
    this.serverWcf,
    this.serverHub,
    this.systemId,
    this.serverSalary,
  });
}
