class StdCodeType {
  static const staffCodetype = "STAFFROLE"; //staffs - role type
  static const staffStatusWorkingCodetype =
      "DRVSTATUSWORK"; //staff - status working

//class StdCodeConstant
  static const failReasonCodetype = "TEFAILREASON";
  static const shuttleTripCodetype = "TESIMORDTRIPTYPE"; //shuttle trip
  static const languageCodetype = "LANGUAGE"; // stdCode2 - users
  static const userRoleCodetype = "USRROLE"; // stdCode2 - users
  static const ownershipCodetype = "OWNERSHIP"; // stdCode - equipment
  static const equipmentGroupCodetype = "EQUIPMENTGROUP"; // stdCode - equipment

}
