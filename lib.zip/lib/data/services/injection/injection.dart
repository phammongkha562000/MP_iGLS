export 'injection_igls.config.dart';
