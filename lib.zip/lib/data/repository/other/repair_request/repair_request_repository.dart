import 'package:dio/dio.dart';
import 'package:igls_new/data/base/abstract_repository.dart';
import 'package:igls_new/data/models/freight_fowarding/to_do_haulage/work_order_status_response.dart';
import 'package:igls_new/data/models/login/data_login_request.dart';
import 'package:igls_new/data/models/other/repair_request/repair_request_request.dart';
import 'package:igls_new/data/services/network/client.dart';
import 'package:igls_new/data/services/result/api_result.dart';
import 'package:injectable/injectable.dart';
import 'package:igls_new/businesses_logics/api/endpoints.dart' as endpoints;
import 'package:sprintf/sprintf.dart';
import 'package:igls_new/presentations/common/constants.dart' as constants;

abstract class AbstractRepairRequestRepository implements AbstractRepository {
  Future<ApiResult> saveRepairRequest(
      {required RepairRequestRequest content, required String subsidiary});
}

@injectable
class RepairRequestRepository implements AbstractRepairRequestRepository {
  AbstractDioHttpClient client;
  RepairRequestRepository({required this.client});

  @override
  Future<ApiResult> saveRepairRequest(
      {required RepairRequestRequest content,
      required String subsidiary}) async {
    try {
      final request = ModelRequest(
          sprintf(endpoints.saveRepairRequest, [subsidiary]),
          body: content.toMap());
      final api = await client.postNew(request, (data) => data);
      if (api is! DioError) {
        return ApiResult.success(data: StatusResponse.fromJson(api));
      } else {
        return ApiResult.fail(
            error: api,
            errorCode: api.response == null
                ? constants.errorNoConnect
                : api.response!.statusCode!);
      }
    } catch (e) {
      return ApiResult.fail(error: e, errorCode: 0);
    }
  }
}
