part of 'relocation_bloc.dart';

abstract class RelocationState extends Equatable {
  const RelocationState();

  @override
  List<Object?> get props => [];
}

class RelocationInitial extends RelocationState {}

class RelocationLoading extends RelocationState {}

class RelocationSuccess extends RelocationState {
  final bool? saveSuccess;
  final DateTime date;
  final List<RelocationResponse> relocationList;
  const RelocationSuccess({
    required this.date,
    required this.relocationList,
    this.saveSuccess,
  });
  @override
  List<Object?> get props => [date, relocationList, saveSuccess];

  RelocationSuccess copyWith({
    bool? saveSuccess,
    DateTime? date,
    List<RelocationResponse>? relocationList,
  }) {
    return RelocationSuccess(
      saveSuccess: saveSuccess ?? this.saveSuccess,
      date: date ?? this.date,
      relocationList: relocationList ?? this.relocationList,
    );
  }
}

class RelocationFailure extends RelocationState {
  final String message;
  final int? errorCode;
  const RelocationFailure({
    required this.message,
    this.errorCode,
  });
  @override
  List<Object?> get props => [message, errorCode];
}
