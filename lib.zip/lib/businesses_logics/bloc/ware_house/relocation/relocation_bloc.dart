// ignore_for_file: avoid_print

import 'dart:developer';

import 'package:easy_localization/easy_localization.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:igls_new/data/services/injection/injection_igls.dart';
import 'package:igls_new/data/services/result/api_result.dart';

import 'package:igls_new/presentations/common/strings.dart' as strings;
import '../../../../data/models/models.dart';
import '../../../../data/repository/repository.dart';
import '../../../../data/shared/shared.dart';
import '../../general/general_bloc.dart';

part 'relocation_event.dart';
part 'relocation_state.dart';

class RelocationBloc extends Bloc<RelocationEvent, RelocationState> {
  final _relocationRepo = getIt<RelocationRepository>();
  // final _logger = Logger(GlobalApp.logz.toString());

  RelocationBloc() : super(RelocationInitial()) {
    on<RelocationViewLoaded>(_mapViewLoadedToState);
    on<RelocationPreviousDateLoaded>(_mapPreviousToState);
    on<RelocationNextDateLoaded>(_mapNextToState);
    on<RelocationSave>(_mapSaveToState);
    on<RelocationPickDate>(_mapPickDateToState);
  }
  Future<ApiResult> _getRelocation(
      {required DateTime eventDate, required UserInfo userInfo}) async {
    final dateFrom = DateFormat('dd/MM/yyyy').format(eventDate);
    final content = RelocationRequest(
        contactCode: userInfo.defaultClient ?? '',
        dcCode: userInfo.defaultCenter ?? '',
        dateFrom: dateFrom,
        dateTo: dateFrom,
        itemCode: '');

    return await _relocationRepo.getRelocation(
        content: content, subsidiaryId: userInfo.subsidiaryId ?? '');
  }

  Future<void> _mapViewLoadedToState(RelocationViewLoaded event, emit) async {
    emit(RelocationLoading());
    try {
      UserInfo userInfo = event.generalBloc.generalUserInfo ?? UserInfo();
      final apiResultRelocation = await _getRelocation(
        userInfo: userInfo,
        eventDate: event.date,
      );
      if (apiResultRelocation.isFailure) {
        emit(RelocationFailure(
            message: apiResultRelocation.getErrorMessage(),
            errorCode: apiResultRelocation.errorCode));
        return;
      }
      List<RelocationResponse> relocationList = apiResultRelocation.data;
      // if (event.pageId != null && event.pageName != null) {
      //   final sharedPref = await SharedPreferencesService.instance;

      //   String accessDatetime = DateTime.now().toString().split('.').first;
      //   final contentQuickMenu = FrequentlyVisitPageRequest(
      //       userId:  event.generalBloc.generalUserInfo?.userId??'',
      //       subSidiaryId:  userInfo.subsidiaryId?? '',
      //       pageId: event.pageId!,
      //       pageName: event.pageName!,
      //       accessDatetime: accessDatetime,
      //       systemId: constants.systemId);
      //   final addFreqVisitResult =
      //       await _loginRepo.saveFreqVisitPage(content: contentQuickMenu);
      //   if (addFreqVisitResult.isFailure) {
      //     emit(RelocationFailure(
      //         message: addFreqVisitResult.getErrorMessage(),
      //         errorCode: addFreqVisitResult.errorCode));
      //     return;
      //   }
      // }
      emit(RelocationSuccess(date: event.date, relocationList: relocationList));
    } catch (e) {
      emit(const RelocationFailure(message: strings.messError));
    }
  }

  Future<void> _mapPreviousToState(
      RelocationPreviousDateLoaded event, emit) async {
    try {
      final currentState = state;
      if (currentState is RelocationSuccess) {
        emit(RelocationLoading());
        UserInfo userInfo = event.generalBloc.generalUserInfo ?? UserInfo();

        final previous = currentState.date.findPreviousDate;
        final apiResultRelocation =
            await _getRelocation(eventDate: previous, userInfo: userInfo);
        if (apiResultRelocation.isFailure) {
          emit(RelocationFailure(
              message: apiResultRelocation.getErrorMessage(),
              errorCode: apiResultRelocation.errorCode));
          return;
        }
        List<RelocationResponse> relocationList = apiResultRelocation.data;
        emit(currentState.copyWith(
          date: previous,
          relocationList: relocationList,
          saveSuccess: false,
        ));
      }
    } catch (e) {
      emit(const RelocationFailure(message: strings.messError));
    }
  }

  Future<void> _mapNextToState(RelocationNextDateLoaded event, emit) async {
    try {
      final currentState = state;
      if (currentState is RelocationSuccess) {
        emit(RelocationLoading());
        final next = currentState.date.findNextDate;
        UserInfo userInfo = event.generalBloc.generalUserInfo ?? UserInfo();

        final apiResultRelocation = await _getRelocation(
          userInfo: userInfo,
          eventDate: next,
        );
        if (apiResultRelocation.isFailure) {
          emit(RelocationFailure(
              message: apiResultRelocation.getErrorMessage(),
              errorCode: apiResultRelocation.errorCode));
          return;
        }
        List<RelocationResponse> relocationList = apiResultRelocation.data;
        emit(currentState.copyWith(
          date: next,
          relocationList: relocationList,
          saveSuccess: false,
        ));
      }
    } catch (e) {
      emit(const RelocationFailure(message: strings.messError));
    }
  }

  Future<void> _mapSaveToState(RelocationSave event, emit) async {
    try {
      final item = event.item;
      final currentState = state;

      if (currentState is RelocationSuccess) {
        emit(RelocationLoading());

        UserInfo userInfo = event.generalBloc.generalUserInfo ?? UserInfo();

        final content = UpdateRelocationRequest(
            id: item.id!,
            dCCode: userInfo.defaultCenter ?? '',
            contactCode: userInfo.defaultClient!,
            plandate: FileUtils.formatDDMMyyyfromString(item.plandate!),
            assignStaff: item.assignStaff ?? '',
            oldLocCode: item.oldLocCode ?? '',
            newLocCode: item.newLocCode ?? '',
            qty: item.qty!,
            isDone: !item.isDone!,
            completeMemo: event.remark,
            updateUser: event.generalBloc.generalUserInfo?.userId ?? '');
        final apiResponse = await _relocationRepo.getUpdateRelocation(
            content: content, subsidiaryId: userInfo.subsidiaryId ?? '');
        log(apiResponse.isSuccess.toString());
        if (apiResponse.isSuccess != true) {
          emit(RelocationFailure(message: apiResponse.message));
          emit(currentState);
          // _logger.severe(
          //   "Error",
          //   content.toMap(),
          // );
          return;
        }
        final apiResultRelocation = await _getRelocation(
            eventDate: currentState.date, userInfo: userInfo);
        if (apiResultRelocation.isFailure) {
          emit(RelocationFailure(
              message: apiResultRelocation.getErrorMessage(),
              errorCode: apiResultRelocation.errorCode));
          return;
        }
        List<RelocationResponse> relocationList = apiResultRelocation.data;
        emit(currentState.copyWith(
          saveSuccess: true,
          relocationList: relocationList,
        ));
      }
    } catch (e) {
      emit(const RelocationFailure(message: strings.messError));
    }
  }

  Future<void> _mapPickDateToState(RelocationPickDate event, emit) async {
    try {
      final currentState = state;
      if (currentState is RelocationSuccess) {
        UserInfo userInfo = event.generalBloc.generalUserInfo ?? UserInfo();

        emit(RelocationLoading());
        final date = event.date;
        final apiResultRelocation =
            await _getRelocation(eventDate: date, userInfo: userInfo);
        if (apiResultRelocation.isFailure) {
          emit(RelocationFailure(
              message: apiResultRelocation.getErrorMessage(),
              errorCode: apiResultRelocation.errorCode));
          return;
        }
        List<RelocationResponse> relocationList = apiResultRelocation.data;
        emit(currentState.copyWith(
          date: date,
          relocationList: relocationList,
          saveSuccess: false,
        ));
      }
    } catch (e) {
      emit(const RelocationFailure(message: strings.messError));
    }
  }
}
