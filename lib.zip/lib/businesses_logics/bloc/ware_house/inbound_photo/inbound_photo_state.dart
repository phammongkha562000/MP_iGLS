part of 'inbound_photo_bloc.dart';

abstract class InboundPhotoState extends Equatable {
  const InboundPhotoState();

  @override
  List<Object?> get props => [];
}

class InboundPhotoInitial extends InboundPhotoState {}

class InboundPhotoLoading extends InboundPhotoState {}

class InboundPhotoSuccess extends InboundPhotoState {
  final DateTime date;
  final bool? isLoading;
  final List<OrderResponse> orderList;
  const InboundPhotoSuccess({
    required this.date,
    this.isLoading,
    required this.orderList,
  });
  @override
  List<Object?> get props => [date, orderList, isLoading];

  InboundPhotoSuccess copyWith({
    DateTime? date,
    bool? isLoading,
    List<OrderResponse>? orderList,
  }) {
    return InboundPhotoSuccess(
      date: date ?? this.date,
      isLoading: isLoading ?? this.isLoading,
      orderList: orderList ?? this.orderList,
    );
  }
}

class InboundPhotoFailure extends InboundPhotoState {
  final String message;
  final int? errorCode;
  const InboundPhotoFailure({
    required this.message,
    this.errorCode,
  });
  @override
  List<Object?> get props => [message, errorCode];
}
