part of 'inbound_photo_bloc.dart';

abstract class InboundPhotoEvent extends Equatable {
  const InboundPhotoEvent();

  @override
  List<Object?> get props => [];
}

class InboundPhotoViewLoaded extends InboundPhotoEvent {
  final DateTime date;
  // final String? pageId;
  // final String? pageName;
  final GeneralBloc generalBloc;
  const InboundPhotoViewLoaded(
      {required this.date,
      // this.pageId,
      // this.pageName,
      required this.generalBloc});
  @override
  List<Object?> get props => [date, generalBloc /* pageId, pageName */];
}

class InboundPhotoPreviousDateLoaded extends InboundPhotoEvent {
  final GeneralBloc generalBloc;
  const InboundPhotoPreviousDateLoaded({
    required this.generalBloc,
  });
  @override
  List<Object?> get props => [generalBloc];
}

class InboundPhotoNextDateLoaded extends InboundPhotoEvent {
  final GeneralBloc generalBloc;
  const InboundPhotoNextDateLoaded({
    required this.generalBloc,
  });
  @override
  List<Object?> get props => [generalBloc];
}

class InboundPhotoPickDate extends InboundPhotoEvent {
  final DateTime date;
  final GeneralBloc generalBloc;
  const InboundPhotoPickDate({
    required this.date,
    required this.generalBloc,
  });
  @override
  List<Object> get props => [date, generalBloc];
}
