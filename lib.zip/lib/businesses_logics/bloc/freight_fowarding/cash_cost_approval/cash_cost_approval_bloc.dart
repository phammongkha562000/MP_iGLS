import 'package:easy_localization/easy_localization.dart';
import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:igls_new/data/models/freight_fowarding/cash_cost_appoval/cash_cost_approval_save_request.dart';
import 'package:igls_new/data/models/freight_fowarding/cash_cost_appoval/cash_cost_request.dart';
import 'package:igls_new/data/models/freight_fowarding/cash_cost_appoval/cost_approval_response.dart';
import 'package:igls_new/data/models/login/login.dart';
import 'package:igls_new/data/repository/freight_fowarding/cash_cost_approval/cash_cost_approval_repository.dart';
import 'package:igls_new/data/services/injection/injection_igls.dart';
import 'package:igls_new/data/services/result/api_result.dart';
import 'package:igls_new/presentations/common/constants.dart' as constants;

import 'package:collection/collection.dart';

import '../../../../data/shared/shared.dart';
import '../../general/general_bloc.dart';

part 'cash_cost_approval_event.dart';
part 'cash_cost_approval_state.dart';

class CashCostApprovalBloc
    extends Bloc<CashCostApprovalEvent, CashCostApprovalState> {
  final _cashCostApprovalRepo = getIt<CashCostApprovalRepository>();

  CashCostApprovalBloc() : super(CashCostApprovalInitial()) {
    on<CashCostApprovalViewLoaded>(_mapViewLoadedToState);
    on<CashCostApprovalPreviousDateLoaded>(_mapPreviousToState);
    on<CashCostApprovalNextDateLoaded>(_mapNextToState);
    on<CashCostApprovalPickDate>(_mapPickDateToState);
    on<CashCostApprovalSelected>(_mapSelectedToState);
    on<CashCostApprovalUpdate>(_mapUpdateToState);
  }
  Future<void> _mapViewLoadedToState(
      CashCostApprovalViewLoaded event, emit) async {
    emit(CashCostApprovalLoading());
    try {
      UserInfo userInfo = event.generalBloc.generalUserInfo ?? UserInfo();

      final apiResult = await _getCashCost(
        subsidiaryId: userInfo.subsidiaryId ?? '',
        defaultBranch: userInfo.defaultBranch ?? '',
        tradeType: event.tradeType,
        eventDate: event.date,
        userId: userInfo.userId ?? '',
      );
      if (apiResult.isFailure) {
        emit(CashCostApprovalFailure(
            message: apiResult.getErrorMessage(),
            errorCode: apiResult.errorCode));
        return;
      }
      final List<CashCostApprovalResponse> cashCostList = apiResult.data;
      _groupCarrierBCNo(list: cashCostList);

      emit(CashCostApprovalSuccess(
        tradeType: event.tradeType,
        date: event.date,
        cashCostList: cashCostList,
      ));
    } catch (e) {
      emit(CashCostApprovalFailure(message: e.toString()));
    }
  }

  Future<void> _mapPickDateToState(CashCostApprovalPickDate event, emit) async {
    try {
      final currentState = state;
      if (currentState is CashCostApprovalSuccess) {
        emit(CashCostApprovalLoading());
        UserInfo userInfo = event.generalBloc.generalUserInfo ?? UserInfo();

        final date = event.date ?? currentState.date;
        final tradeType = event.tradeType ?? currentState.tradeType;
        final apiResult = await _getCashCost(
          subsidiaryId: userInfo.subsidiaryId ?? '',
          defaultBranch: userInfo.defaultBranch ?? '',
          tradeType: tradeType,
          eventDate: date,
          userId: event.generalBloc.generalUserInfo?.userId ?? '',
        );
        if (apiResult.isFailure) {
          emit(CashCostApprovalFailure(
              message: apiResult.getErrorMessage(),
              errorCode: apiResult.errorCode));
          return;
        }
        final List<CashCostApprovalResponse> cashCostList = apiResult.data;

        _groupCarrierBCNo(list: cashCostList);

        emit(CashCostApprovalSuccess(
            tradeType: tradeType, date: date, cashCostList: cashCostList));
      }
    } catch (e) {
      emit(CashCostApprovalFailure(message: e.toString()));
    }
  }

  Future<void> _mapPreviousToState(
      CashCostApprovalPreviousDateLoaded event, emit) async {
    try {
      final currentState = state;
      if (currentState is CashCostApprovalSuccess) {
        UserInfo userInfo = event.generalBloc.generalUserInfo ?? UserInfo();
        emit(CashCostApprovalLoading());
        final previous = currentState.date.findPreviousDate;
        final apiResult = await _getCashCost(
          subsidiaryId: userInfo.subsidiaryId ?? '',
          defaultBranch: userInfo.defaultBranch ?? '',
          tradeType: currentState.tradeType,
          eventDate: previous,
          userId: userInfo.userId ?? '',
        );
        if (apiResult.isFailure) {
          emit(CashCostApprovalFailure(
              message: apiResult.getErrorMessage(),
              errorCode: apiResult.errorCode));
          return;
        }
        final List<CashCostApprovalResponse> cashCostList = apiResult.data;

        _groupCarrierBCNo(list: cashCostList);

        emit(currentState.copyWith(date: previous, cashCostList: cashCostList));
      }
    } catch (e) {
      emit(CashCostApprovalFailure(message: e.toString()));
    }
  }

  Future<void> _mapNextToState(
      CashCostApprovalNextDateLoaded event, emit) async {
    try {
      final currentState = state;
      if (currentState is CashCostApprovalSuccess) {
        emit(CashCostApprovalLoading());
        UserInfo userInfo = event.generalBloc.generalUserInfo ?? UserInfo();

        final next = currentState.date.findNextDate;
        final apiResult = await _getCashCost(
          subsidiaryId: userInfo.subsidiaryId ?? '',
          defaultBranch: userInfo.defaultBranch ?? '',
          tradeType: currentState.tradeType,
          eventDate: next,
          userId: userInfo.userId ?? '',
        );
        if (apiResult.isFailure) {
          emit(CashCostApprovalFailure(
              message: apiResult.getErrorMessage(),
              errorCode: apiResult.errorCode));
          return;
        }
        final List<CashCostApprovalResponse> cashCostList = apiResult.data;
        _groupCarrierBCNo(list: cashCostList);
        emit(currentState.copyWith(date: next, cashCostList: cashCostList));
      }
    } catch (e) {
      emit(CashCostApprovalFailure(message: e.toString()));
    }
  }

  Future<void> _mapSelectedToState(CashCostApprovalSelected event, emit) async {
    try {
      final currentState = state;
      if (currentState is CashCostApprovalSuccess) {
        emit(CashCostApprovalLoading());
        List<CashCostApproval> cashCostSelect = [];
        for (var e in event.cashCostList) {
          cashCostSelect = currentState.cashCostList[event.index].items!
              .map((element) => element.woNo == e.woNo
                  ? element.copyWith(isSelected: event.isSelected)
                  : element)
              .toList();
        }

        final list2 = currentState.cashCostList
            .map((e) => currentState.cashCostList[event.index] == e
                ? currentState.cashCostList[event.index]
                    .copyWith(items: cashCostSelect)
                : e)
            .toList();

        _groupCarrierBCNo(list: list2);

        emit(currentState.copyWith(isSuccess: null, cashCostList: list2));
      }
    } catch (e) {
      emit(CashCostApprovalFailure(message: e.toString()));
    }
  }

  Future<void> _mapUpdateToState(CashCostApprovalUpdate event, emit) async {
    try {
      final List<int> cwoId = [];
      final List<int> cwoCId = [];
      UserInfo userInfo = event.generalBloc.generalUserInfo ?? UserInfo();

      final currentState = state;
      if (currentState is CashCostApprovalSuccess) {
        emit(CashCostApprovalLoading());

        for (var item in currentState.cashCostList) {
          for (var item2 in item.items!) {
            if (item2.isSelected == true) {
              if (item2.costSource == 'BL') {
                cwoId.add(item2.docId!);
              } else {
                cwoCId.add(item2.docId!);
              }
            }
          }
        }
        if (cwoCId.isEmpty && cwoId.isEmpty) {
          emit(const CashCostApprovalFailure(message: '5166'));
          emit(currentState.copyWith(isSuccess: null));
          return;
        }
        String cwoidStr = cwoId.join(',');
        String cwocidStr = cwoCId.join(',');
        final content = CashCostApprovalSaveRequest(
            contactCode: userInfo.defaultClient ?? '',
            cwoId: cwoidStr,
            cwoCId: cwocidStr,
            userId: userInfo.userId ?? '');
        final apiResponse = await _cashCostApprovalRepo.getCashCostApprovalSave(
            content: content, subsidiaryId: userInfo.subsidiaryId!);
        if (apiResponse.isSuccess != true) {
          emit(currentState.copyWith(
            isSuccess: false,
          ));
          return;
        }

        final apiResult = await _getCashCost(
          subsidiaryId: userInfo.subsidiaryId ?? '',
          defaultBranch: userInfo.defaultBranch ?? '',
          tradeType: currentState.tradeType,
          eventDate: currentState.date,
          userId: userInfo.userId ?? '',
        );
        if (apiResult.isFailure) {
          emit(CashCostApprovalFailure(
              message: apiResult.getErrorMessage(),
              errorCode: apiResult.errorCode));
          return;
        }
        final List<CashCostApprovalResponse> cashCostList = apiResult.data;
        _groupCarrierBCNo(list: cashCostList);
        emit(
            currentState.copyWith(cashCostList: cashCostList, isSuccess: true));
      }
    } catch (e) {
      emit(CashCostApprovalFailure(message: e.toString()));
    }
  }

  Future<ApiResult> _getCashCost(
      {required String tradeType,
      required DateTime eventDate,
      required String defaultBranch,
      required String userId,
      required String subsidiaryId}) async {
    final content = BulkCostApprovalSearchRequest(
        contactCode: '',
        tradeType: tradeType,
        reqDateF: DateFormat(constants.formatyyyyMMdd).format(eventDate),
        reqDateT: DateFormat(constants.formatyyyyMMdd).format(eventDate),
        createUser: userId,
        woNo: '',
        blNo: '',
        cntrNo: '',
        paymentMode: 'CATR,BTRF',
        approvalMode: 'UAPPV',
        payToContactCode: '',
        accountCode: '',
        branchCode: defaultBranch);

    return await _cashCostApprovalRepo.getCashCostApproval(
        content: content, subsidiaryId: subsidiaryId);
  }

  List<CashCostApprovalResponse> _groupCarrierBCNo(
      {required List<CashCostApprovalResponse> list}) {
    for (var element in list) {
      final menuGroupBy = groupBy(
          element.items!,
          (CashCostApproval elm) =>
              (elm.carrierBcNo != '' && elm.carrierBcNo != null)
                  ? elm.carrierBcNo
                  : elm.blNo);

      element.itemGroup =
          menuGroupBy.entries.map((entry) => entry.value).toList();
    }
    return list;
  }
}
