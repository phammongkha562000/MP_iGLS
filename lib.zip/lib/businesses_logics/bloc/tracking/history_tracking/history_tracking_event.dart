part of 'history_tracking_bloc.dart';

sealed class HistoryTrackingEvent extends Equatable {
  const HistoryTrackingEvent();

  @override
  List<Object> get props => [];
}

class HistoryTrackingViewLoaded extends HistoryTrackingEvent {}
