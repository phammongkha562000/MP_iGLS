part of 'history_tracking_bloc.dart';

sealed class HistoryTrackingState extends Equatable {
  const HistoryTrackingState();

  @override
  List<Object> get props => [];
}

final class HistoryTrackingInitial extends HistoryTrackingState {}

final class HistoryTrackingLoading extends HistoryTrackingState {}

final class HistoryTrackingSuccess extends HistoryTrackingState {
  final List<LatLng> latLngLst;

  const HistoryTrackingSuccess({required this.latLngLst});
  @override
  List<Object> get props => [latLngLst];
}

final class HistoryTrackingFailure extends HistoryTrackingState {}
