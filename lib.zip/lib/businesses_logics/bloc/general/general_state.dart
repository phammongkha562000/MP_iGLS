part of 'general_bloc.dart';

class GeneralState extends Equatable {
  const GeneralState();

  @override
  List<Object> get props => [];
}

class GeneralInitial extends GeneralState {}

class GeneralSuccess extends GeneralState {}

class GeneralFailure extends GeneralState {}
