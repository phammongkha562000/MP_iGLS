import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:equatable/equatable.dart';
import 'package:igls_new/data/repository/local_distribution/history_todo/history_todo_repository.dart';
import 'package:igls_new/data/services/result/api_result.dart';
import 'package:igls_new/data/shared/preference/share_pref_service.dart';

import '../../../../data/models/models.dart';
import '../../../../data/services/injection/injection_igls.dart';

import 'package:igls_new/presentations/common/strings.dart' as strings;
import 'package:igls_new/presentations/common/constants.dart' as constants;

import '../../general/general_bloc.dart';

part 'history_todo_event.dart';
part 'history_todo_state.dart';

class HistoryTodoBloc extends Bloc<HistoryTodoEvent, HistoryTodoState> {
  final _historyTodoRepository = getIt<HistoryTodoRepository>();

  HistoryTodoBloc() : super(HistoryTodoInitial()) {
    on<HistoryTodoLoaded>(_mapViewToState);
    on<HistoryTodoNextMonth>(_mapNextMonthToState);
    on<HistoryTodoPreviousMonth>(_mapPreviousMonthToState);
  }

  Future<ApiResult> _getHistoryTodo(
      {required DateTime eventDate,
      required String empCode,
      required String subsidiaryId}) async {
    final date = DateFormat(constants.formatyyyyMMdd).format(eventDate);
    return await _historyTodoRepository.getListHistoryTodo(
      date: date,
      driverId: empCode,
      subsidiaryId: subsidiaryId,
    );
  }

  void _mapViewToState(HistoryTodoLoaded event, emit) async {
    try {
      emit(HistoryTodoLoading());

      final sharedPref = await SharedPreferencesService.instance;
      UserInfo userInfo = event.generalBloc.generalUserInfo ?? UserInfo();

      final equipmentCode = sharedPref.equipmentNo;
      final driverId = event.generalBloc.generalUserInfo?.empCode ?? '';
      if (equipmentCode == null || equipmentCode == "" || driverId == "") {
        emit(const HistoryTodoFailure(
            message: strings.messErrorNoEquipment,
            errorCode: constants.errorNullEquipDriverId));
        emit(HistoryTodoSuccess(
            date: DateTime.now(), listHistoryTodo: const []));
        return;
      }
      final apiResultHistory = await _getHistoryTodo(
          subsidiaryId: userInfo.subsidiaryId ?? "",
          empCode: event.generalBloc.generalUserInfo?.empCode ?? '',
          eventDate: DateTime(event.date.year, event.date.month, 15));
      if (apiResultHistory.isFailure) {
        emit(HistoryTodoFailure(
            message: apiResultHistory.getErrorMessage(),
            errorCode: apiResultHistory.errorCode));
        return;
      }
      HistoryTodoResponse historyTodoResponse = apiResultHistory.data;
      List<HistoryNormalTrip> listHistory =
          historyTodoResponse.normalTrip ?? [];
      // if (event.pageId != null && event.pageName != null) {
      //   String accessDatetime = DateTime.now().toString().split('.').first;
      //   final contentQuickMenu = FrequentlyVisitPageRequest(
      //       userId:  event.generalBloc.generalUserInfo?.userId??'',
      //       subSidiaryId:  userInfo.subsidiaryId?? '',
      //       pageId: event.pageId!,
      //       pageName: event.pageName!,
      //       accessDatetime: accessDatetime,
      //       systemId: constants.systemId);
      //    final addFreqVisitResult =
      //     await _loginRepo.saveFreqVisitPage(content: contentQuickMenu);
      // if (addFreqVisitResult.isFailure) {
      //   emit(HistoryTodoFailure(
      //       message: addFreqVisitResult.getErrorMessage(),
      //       errorCode: addFreqVisitResult.errorCode));
      //   return;
      // }
      // }

      emit(HistoryTodoSuccess(
        date: event.date,
        listHistoryTodo: listHistory,
      ));
    } catch (e) {
      emit(const HistoryTodoFailure(message: strings.messError));
    }
  }

  Future<void> _mapNextMonthToState(HistoryTodoNextMonth event, emit) async {
    try {
      final currentState = state;
      if (currentState is HistoryTodoSuccess) {
        emit(HistoryTodoLoading());
        UserInfo userInfo = event.generalBloc.generalUserInfo ?? UserInfo();

        final nextMonth =
            DateTime(currentState.date.year, currentState.date.month + 1, 15);
        final apiResultHistory = await _getHistoryTodo(
            subsidiaryId: userInfo.subsidiaryId ?? "",
            eventDate: nextMonth,
            empCode: event.generalBloc.generalUserInfo?.empCode ?? '');
        if (apiResultHistory.isFailure) {
          emit(HistoryTodoFailure(
              message: apiResultHistory.getErrorMessage(),
              errorCode: apiResultHistory.errorCode));
          return;
        }
        HistoryTodoResponse historyTodoResponse = apiResultHistory.data;
        List<HistoryNormalTrip> listHistory =
            historyTodoResponse.normalTrip ?? [];
        emit(currentState.copyWith(
            date: nextMonth, listHistoryTodo: listHistory));
      }
    } catch (e) {
      emit(const HistoryTodoFailure(message: strings.messError));
    }
  }

  Future<void> _mapPreviousMonthToState(
      HistoryTodoPreviousMonth event, emit) async {
    try {
      final currentState = state;
      if (currentState is HistoryTodoSuccess) {
        emit(HistoryTodoLoading());
        final previousMonth =
            DateTime(currentState.date.year, currentState.date.month - 1, 15);
        UserInfo userInfo = event.generalBloc.generalUserInfo ?? UserInfo();

        final apiResultHistory = await _getHistoryTodo(
            subsidiaryId: userInfo.subsidiaryId ?? "",
            eventDate: previousMonth,
            empCode: event.generalBloc.generalUserInfo?.empCode ?? '');
        if (apiResultHistory.isFailure) {
          emit(HistoryTodoFailure(
              message: apiResultHistory.getErrorMessage(),
              errorCode: apiResultHistory.errorCode));
          return;
        }
        HistoryTodoResponse historyTodoResponse = apiResultHistory.data;
        List<HistoryNormalTrip> listHistory =
            historyTodoResponse.normalTrip ?? [];
        emit(currentState.copyWith(
            date: previousMonth, listHistoryTodo: listHistory));
      }
    } catch (e) {
      emit(const HistoryTodoFailure(message: strings.messError));
    }
  }
}
