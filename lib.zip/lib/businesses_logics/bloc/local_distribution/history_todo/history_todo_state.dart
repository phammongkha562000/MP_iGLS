part of 'history_todo_bloc.dart';

abstract class HistoryTodoState extends Equatable {
  const HistoryTodoState();

  @override
  List<Object?> get props => [];
}

class HistoryTodoInitial extends HistoryTodoState {}

class HistoryTodoLoading extends HistoryTodoState {}

class HistoryTodoSuccess extends HistoryTodoState {
  final DateTime date;
  final List<HistoryNormalTrip>? listHistoryTodo;
  const HistoryTodoSuccess({
    required this.date,
    this.listHistoryTodo,
  });
  @override
  List<Object?> get props => [listHistoryTodo, date];

  HistoryTodoSuccess copyWith({
    DateTime? date,
    List<HistoryNormalTrip>? listHistoryTodo,
  }) {
    return HistoryTodoSuccess(
      date: date ?? this.date,
      listHistoryTodo: listHistoryTodo ?? this.listHistoryTodo,
    );
  }
}

class HistoryTodoFailure extends HistoryTodoState {
  final String message;
  final int? errorCode;
  const HistoryTodoFailure({
    required this.message,
    this.errorCode,
  });
  @override
  List<Object?> get props => [message, errorCode];
}
