part of 'history_todo_bloc.dart';

abstract class HistoryTodoEvent extends Equatable {
  const HistoryTodoEvent();

  @override
  List<Object?> get props => [];
}

class HistoryTodoLoaded extends HistoryTodoEvent {
  final DateTime date;
  // final String? pageId;
  // final String? pageName;
  final GeneralBloc generalBloc;

  const HistoryTodoLoaded({
    required this.date,
    // this.pageId,
    // this.pageName,
    required this.generalBloc,
  });
  @override
  List<Object?> get props => [date, /* pageId, pageName */ generalBloc];
}

class HistoryTodoNextMonth extends HistoryTodoEvent {
  final GeneralBloc generalBloc;
  const HistoryTodoNextMonth({
    required this.generalBloc,
  });
  @override
  List<Object?> get props => [generalBloc];
}

class HistoryTodoPreviousMonth extends HistoryTodoEvent {
  final GeneralBloc generalBloc;
  const HistoryTodoPreviousMonth({
    required this.generalBloc,
  });
  @override
  List<Object?> get props => [generalBloc];
}

// class HistoryTodoPickMonth extends HistoryTodoEvent {
//   final DateTime date;
//   const HistoryTodoPickDate({
//     required this.date,
//   });
//   @override
//   List<Object> get props => [date];
// }
