// ignore_for_file: constant_identifier_names

class ServerMode {
  static const String PROD = "PROD";
  static const String DEV = "DEV";
  static const String QA = "QA";
}
